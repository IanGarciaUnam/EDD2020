package mx.unam.ciencias.edd.proyecto3;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.FileReader;
import java.io.File;
import java.util.Iterator;
import mx.unam.ciencias.edd.Lista;
import mx.unam.ciencias.edd.Diccionario;
import mx.unam.ciencias.edd.FabricaDispersores;
import mx.unam.ciencias.edd.Dispersor;
import mx.unam.ciencias.edd.Dispersores;
import mx.unam.ciencias.edd.AlgoritmoDispersor;


  public class Entrada{

    /**Lista de archivos a directorio**/
    //private Lista<String> archivos;
    /**Bandera de directorio**/
    boolean hayDirectorio;
    /**Nombre del directorio**/
    private String directorio;
    /**
    *Constructor de la clase Entrada, inicializa la Lista de Palabras
    *
    */
    Entrada(boolean hayDirectorio, String directorio){

      if(directorio==null){
      	System.err.println("Tras la bandera \'-0\' deberas ingresar el nombre de tu directorio");
      	System.err.println("Para más ayuda java -jar target/proyecto3.jar --h");
      	System.exit(1);
      }

      this.hayDirectorio=hayDirectorio;

      File dir= new File(directorio);
      if(dir.exists() && !dir.isDirectory()){
      	System.err.println("El directorio "+directorio+" No es un directorio");
      	System.err.println("Cambie de directorio o tecleé alguno diferente");
      	System.err.println("Para más ayuda java -jar target/proyecto3.jar --h");
      	System.exit(1);
      }else if(dir.exists() && dir.isDirectory()){
      	if(!dir.canWrite()){
      		System.err.println("No cuentas con los permisos necesarios para ocupar el directorio "+ directorio);
      		System.err.println("Cambie de directorio o tecleé alguno diferente");
      		System.err.println("Para más ayuda java -jar target/proyecto3.jar --h");
      		System.exit(1);
      	}
      	
      }
      this.directorio=directorio;

      
    }


    /**
    *Itera archivo por archivo para vaciar la Lista de palabras
    *
    */
    public void entradaArgs(String[] args){


		Lista<ArchivoHTML> archivosHTML= new Lista<ArchivoHTML>();
		Diccionario<String,Integer> d=null;
       for(String s: args){
       	 if(!s.equals("-o") && !s.equals(directorio )){
       		//MODIFICAR NO OMITE CAMBIOS ^ "" EN PALABRAS
       	 	 d=getDiccionario(s);
       	 	 
       	 	ArchivoHTML a=new ArchivoHTML(s, d, directorio);
       	 	archivosHTML.agrega(a); 	
       	 }
       	  
	      	
	    }
	    


	    escribeDirectorio();
	    FabricaHTML fabrica= new FabricaHTML(archivosHTML, directorio);
	    fabrica.generaIndex();
	    fabrica.generaHTML();


	}




    private Diccionario<String, Integer> getDiccionario(String archivo){

    			AlgoritmoDispersor a = AlgoritmoDispersor.BJ_STRING;
        		Dispersor<String> bj = FabricaDispersores.dispersorCadena(a);//Configura Dispersor
    	      Diccionario<String, Integer> d= new Diccionario<String, Integer>(bj);


      try{
        BufferedReader br = new BufferedReader(new FileReader(archivo));
        String firstLecture;
        while((firstLecture=br.readLine()) != null){
          String [] toRead=separador(firstLecture);
          for(String s:toRead){
          	s=s.trim();
          	if(!s.equals("")){
          		Palabra temp= new Palabra(s);
          	if(d.contiene(temp.toString())){
          		
           		d.agrega(temp.toString(),d.get(temp.toString())+1);
           	}else{	
           	d.agrega(temp.toString(),1);
           	}	
          	}
          	


          }
        }

        //System.out.println(d.toString());
        br.close();

      }catch(IOException io){
        System.err.println("Error al leer el archivo: "+ archivo);
        
        System.exit(1);
      }

      return d;
    }



        

    private String[] separador(String s){
      String [] nuevo= s.split(" ");
      return nuevo;
    }


    private void escribeDirectorio(){
      if(hayDirectorio && directorio != null){
          File f = new File(directorio);
          if(f.exists()){
            if(f.canWrite())
              f.mkdir();
            else{
              System.out.println("No cuentas con permisos de escritura para el directorio:"+ directorio);
              return;
            }

          }else
            f.mkdirs();
      }else{
      	  File f = new File(directorio);
      	  f.mkdirs();
        System.out.println("Usted debe ingresar la Bandera \"-o\"  seguido del directorio ");
        System.out.println("El directorio generado será nombrado por default: \'directorio\'");
        System.out.println("Para mas ayuda: java -jar target/proyecto3 --h");
        return;
      }
    }



  


  }
