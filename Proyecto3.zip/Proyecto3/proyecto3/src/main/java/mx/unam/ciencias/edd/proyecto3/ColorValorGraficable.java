package mx.unam.ciencias.edd.proyecto3;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.File;
import mx.unam.ciencias.edd.Lista;
import mx.unam.ciencias.edd.Diccionario;
  public class ColorValorGraficable{
    /**Contiene un menu de colores**/
    private String[] color={"#700430","#3f0b20", "#d10202", "#f65012","#f6b412", "#fdd300","red","white", "tomato", "orange","green", "black","blue", };
    /**COntiene un nuevo menu de Colores más pequeño que color[]**/
    private String[] myColor={"red","white", "tomato", "orange","green", "black" };
    /**ValorGraficable**/
    private ValorGraficable v;
    /**Color nuevo por asignar**/
    private String newColor;
    /**
    *Constructor con el nombre del archivo
    *@param v ValorGraficable
    */
    ColorValorGraficable(ValorGraficable v){   
           this.v=v;
    }

    ColorValorGraficable(String newColor){
      this.newColor=newColor;
      v=null;
    }
   /**
   *Regresa el color del valorGraficable en Hexadecimal
   *@return color[i] color para 
   */
    public String getColor(){
       if(v==null)
        return newColor;

          int modifica=v.getPalabra().getElementos();
      int modificador=v.getPalabra().toString().length();
      modifica+=modificador+1479;
        int i=(int)Math.round(modifica%12);
        return color[i];
    }

    /**
    *Regresa Color para graficas de Pastel
    *@return myColor
    */
    public String getColorPieChart(){

      if(v==null)
        return newColor;
      

      int modifica=v.getPalabra().getElementos();
      int modificador=v.getPalabra().toString().length();
      modifica+=modificador;
      int i=(int)Math.round(modifica %5);
        return myColor[i];

    }


    /**
    *Registra un nuevo color; actualizado
    *@param color String de color
    */
    public void setColorNuevo(String color){
      this.newColor=color;
    }

    /**
    *Accede al nuevo color y lo devuelve
    *@return newColor
    */
    public String  getColorNuevo(){
      return this.newColor;
    }

  }