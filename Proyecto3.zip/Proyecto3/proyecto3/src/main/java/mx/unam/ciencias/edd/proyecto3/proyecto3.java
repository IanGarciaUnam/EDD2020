package mx.unam.ciencias.edd.proyecto3;


  public class proyecto3{

    public static void main(String[] args){
    	if(args[0]=="--h"){
    		proyecto3.ayuda();
    		return;
    	}


    	if(!hayDirectorio(args)){
    		System.err.println("Debe ingresar la bandera \'-o\' seguida del nombre del Directorio");
    		System.err.println("Para más ayuda java -jar target/proyecto3.jar --h");
    		return;
	    	}
      Entrada e= new Entrada(hayDirectorio(args), getDirectorio(args));
      e.entradaArgs(args);

    }


    private static void ayuda(){
    	System.out.println("Usó:  java -jar target/proyecto3 <Archivos> <Archivos> -o <Directorio> ");
    	System.out.println("Tras la bandera \'-o\' debera escirbir un Directorio\n asegurese de contar con los permisos necesarios, en caso de que el directorio no exista se creará un directorio con el mismo nombre");
    }

    private static boolean hayDirectorio(String[] args){
      for(String s:args)
        if(s.equals("-o"))return true;
      return false;
    }

    private static String getDirectorio(String[] args){
      if(!hayDirectorio(args)) return null;

      for(int i=0; i<args.length; i++)
        if(args[i].equals("-o")){
          i++;
            return i>=args.length? null:args[i];
        }
      return null;
    }


  

  }
