Estructuras de Datos
====================

Proyecto 3: COntador de Palabras HTML
-----------------------
Ian Israel García Vázquez
### Fecha de entrega:  19 de Junio de 2020

Para usar proyecto 3 debes escribir

```
$ mvn compile
```
```
$ mvn install
```
```
java -jar target/proyecto2.jar [Your File] -o [directorio]
```

```

El archivo a leer no necesita ninguna especificación.
Los caracteres especiales serán ignorados, luego mató<->mato serán consideradas igual.
