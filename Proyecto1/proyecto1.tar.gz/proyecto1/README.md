Estructuras de Datos
====================

Proyecto 1 : Ordenador Léxico Gráfico
Autor: Ian Israel García Vázquez
---------------------------------------------------

### Fecha de entrega: 27/03/2020

Para comenzar a utlizar el ordenador lexico gráfico deben usar los siguientes comandos:

['mvn install'] -> para observar las opciones disponibles puedes utilizar 

['java -jar target/proyecto1.jar --h '] y un menú de ayuda será desplegado


Por otro lado para comenzar a utlizarlo cuenta con dos opciones 
[´-r'] tras ordenar tu archivo de texto será devuelto de reversa por la salida estandar
['-o'] este parametro debeŕas utilizarlo  colocando a lo menos un archivo existente antes del identificador y uno despues; el resultado será escrito en el archivo inmediato siguiente a ['-o']

para ingresar tus archivos puedes usar la entrada estandar 

['cat file1 ... file_n | java -jar target/proyecto1.jar <opcion(es)>' ]

o bien ['java -jar target/proyecto1.jar <opciones> (file(s)) ']

y para el caso de emplear la bandera "-o" 

### java -jar target/proyecto1.jar file(s) -o file
###cat file(s) | java -jar target/proyecto1.jar -o file


%%% Información de contacto
	Ian Israel García Vázquez iangarcia@ciencias.unam.mx



 




